
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-white dark:bg-secondary-light mt-12 py-8 px-4 sm:px-6 lg:px-8 shadow-inner">
            <div className="container mx-auto text-center text-gray-500 dark:text-text-secondary">
                <p className="font-bold text-lg text-gray-800 dark:text-white mb-2">
                    🎮 Ultimate AI Game Portal
                </p>
                <p className="text-sm">
                    Your premier destination for free HTML5 games, enhanced with AI. Play instantly in your browser.
                </p>
                <div className="mt-4">
                     <p className="text-xs">&copy; {new Date().getFullYear()} Ultimate AI Game Portal. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
