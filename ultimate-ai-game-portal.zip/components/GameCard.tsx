
import React from 'react';
import { Game, ViewMode } from '../types';
import { StarIcon } from './Icons';

interface GameCardProps {
    game: Game;
    viewMode: ViewMode;
    onSelectGame: (game: Game) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, viewMode, onSelectGame }) => {
    const isGrid = viewMode === ViewMode.GRID;

    const cardClasses = isGrid
        ? 'flex flex-col'
        : 'flex flex-row items-center';
        
    const imageContainerClasses = isGrid 
        ? 'w-full h-48' 
        : 'w-32 h-20 flex-shrink-0';
    
    const contentClasses = isGrid 
        ? 'pt-4' 
        : 'pl-4 flex-grow';

    return (
        <div
            onClick={() => onSelectGame(game)}
            className={`bg-white dark:bg-secondary-light rounded-xl shadow-md overflow-hidden transform hover:-translate-y-1 hover:shadow-xl transition-all duration-300 cursor-pointer ${cardClasses}`}
        >
            <div className={`relative ${imageContainerClasses}`}>
                <img className="w-full h-full object-cover" src={game.imageUrl} alt={game.title} />
                 <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                    <StarIcon className="w-4 h-4 text-yellow-400" />
                    <span>{game.rating.toFixed(1)}</span>
                </div>
            </div>
            <div className={`p-4 ${contentClasses}`}>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white truncate" title={game.title}>{game.title}</h3>
                <p className="text-sm text-gray-500 dark:text-text-secondary">{game.category}</p>
                 { !isGrid && <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 line-clamp-2">{game.description}</p> }
            </div>
        </div>
    );
};

export default GameCard;
