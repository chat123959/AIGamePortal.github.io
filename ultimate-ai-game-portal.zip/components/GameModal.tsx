
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { Game } from '../types';
import { CloseIcon } from './Icons';

interface GameModalProps {
    game: Game;
    onClose: () => void;
}

const GameModal: React.FC<GameModalProps> = ({ game, onClose }) => {
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose]);
    
    const modalContent = (
         <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 animate-fade-in"
            aria-modal="true"
            role="dialog"
            aria-labelledby="modalTitle"
        >
            <div 
                className="fixed inset-0" 
                onClick={onClose} 
                aria-hidden="true"
            ></div>
            <div className="relative bg-secondary-light rounded-2xl shadow-2xl w-full max-w-4xl h-full max-h-[90vh] flex flex-col mx-4 animate-slide-up">
                <header className="flex justify-between items-center p-4 border-b border-gray-600 flex-shrink-0">
                    <h3 id="modalTitle" className="text-xl font-bold text-white">{game.title}</h3>
                    <button
                        onClick={onClose}
                        className="p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors"
                        aria-label="Close game"
                    >
                       <CloseIcon />
                    </button>
                </header>
                <div className="flex-grow relative bg-black">
                    {isLoading && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black">
                            <div className="w-16 h-16 border-4 border-t-transparent border-primary rounded-full animate-spin"></div>
                            <p className="mt-4 text-lg">Loading Game...</p>
                        </div>
                    )}
                    <iframe
                        id="gameFrame"
                        className={`w-full h-full border-0 ${isLoading ? 'opacity-0' : 'opacity-100 transition-opacity'}`}
                        src={game.gameUrl === '#' ? 'about:blank' : game.gameUrl}
                        title={game.title}
                        onLoad={() => setIsLoading(false)}
                        allowFullScreen
                    ></iframe>
                </div>
            </div>
        </div>
    );
    
    const modalRoot = document.getElementById('modal-root');
    return modalRoot ? ReactDOM.createPortal(modalContent, modalRoot) : null;
};

export default GameModal;
