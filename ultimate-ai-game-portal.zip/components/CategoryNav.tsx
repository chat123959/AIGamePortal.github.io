
import React from 'react';
import { GameCategory } from '../types';

interface CategoryNavProps {
    categories: { name: GameCategory, icon: string }[];
    selectedCategory: GameCategory;
    setSelectedCategory: (category: GameCategory) => void;
}

const CategoryNav: React.FC<CategoryNavProps> = ({ categories, selectedCategory, setSelectedCategory }) => {
    return (
        <nav className="my-8" aria-label="Game categories">
            <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
                {categories.map(category => (
                    <button
                        key={category.name}
                        onClick={() => setSelectedCategory(category.name)}
                        className={`px-4 py-2 text-sm sm:text-base font-semibold rounded-full flex items-center gap-2 transition-all duration-200 transform hover:scale-105 ${
                            selectedCategory === category.name
                                ? 'bg-primary text-white shadow-lg'
                                : 'bg-white dark:bg-secondary-light text-gray-700 dark:text-text-secondary hover:bg-gray-200 dark:hover:bg-gray-600'
                        }`}
                        aria-pressed={selectedCategory === category.name}
                    >
                        <span>{category.icon}</span>
                        <span>{category.name}</span>
                    </button>
                ))}
            </div>
        </nav>
    );
};

export default CategoryNav;
