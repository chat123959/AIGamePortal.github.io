
import React from 'react';
import { ViewMode } from '../types';

interface SkeletonCardProps {
    viewMode: ViewMode;
}

const SkeletonCard: React.FC<SkeletonCardProps> = ({ viewMode }) => {
    const isGrid = viewMode === ViewMode.GRID;

    const cardClasses = isGrid
        ? 'flex flex-col'
        : 'flex flex-row items-center';
        
    const imageContainerClasses = isGrid 
        ? 'w-full h-48' 
        : 'w-32 h-20 flex-shrink-0';

    const contentClasses = isGrid 
        ? 'pt-4' 
        : 'pl-4 flex-grow';

    return (
        <div className={`bg-white dark:bg-secondary-light rounded-xl shadow-md overflow-hidden ${cardClasses}`}>
            <div className={`bg-gray-300 dark:bg-gray-700 animate-pulse-slow ${imageContainerClasses}`}></div>
            <div className={`p-4 ${contentClasses}`}>
                <div className="h-6 w-3/4 bg-gray-300 dark:bg-gray-700 rounded animate-pulse-slow mb-2"></div>
                <div className="h-4 w-1/2 bg-gray-300 dark:bg-gray-700 rounded animate-pulse-slow"></div>
            </div>
        </div>
    );
};

export default SkeletonCard;
