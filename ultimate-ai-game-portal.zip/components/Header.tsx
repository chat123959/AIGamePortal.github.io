
import React from 'react';
import { SparklesIcon, SearchIcon } from './Icons';

interface HeaderProps {
    searchTerm: string;
    setSearchTerm: (term: string) => void;
    onOpenSuggester: () => void;
}

const Header: React.FC<HeaderProps> = ({ searchTerm, setSearchTerm, onOpenSuggester }) => {
    return (
        <header className="bg-white dark:bg-secondary-light shadow-md w-full py-6 px-4 sm:px-6 lg:px-8">
            <div className="container mx-auto text-center">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 dark:text-white flex items-center justify-center gap-3">
                    <span className="text-primary">🎮</span>
                    <span>Ultimate AI Game Portal</span>
                </h1>
                <p className="mt-2 text-lg text-gray-500 dark:text-text-secondary">
                    Discover and Play the Best Free HTML5 Games
                </p>
                <div className="mt-6 max-w-2xl mx-auto flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-grow">
                        <input
                            type="text"
                            className="w-full pl-12 pr-4 py-3 rounded-full border-2 border-transparent bg-gray-100 dark:bg-secondary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                            placeholder="Search for games..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            aria-label="Search games"
                        />
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500">
                            <SearchIcon />
                        </div>
                    </div>
                    <button 
                        onClick={onOpenSuggester}
                        className="flex-shrink-0 bg-gradient-to-r from-primary to-accent hover:from-primary-hover hover:to-pink-600 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 transition-all transform hover:scale-105"
                        aria-label="Get AI game suggestion"
                    >
                        <SparklesIcon />
                        <span className="hidden sm:inline">AI Suggest</span>
                        <span className="sm:hidden">Suggest</span>
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;
