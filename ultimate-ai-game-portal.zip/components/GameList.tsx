
import React from 'react';
import { Game, ViewMode } from '../types';
import GameCard from './GameCard';
import SkeletonCard from './SkeletonCard';

interface GameListProps {
    games: Game[];
    isLoading: boolean;
    viewMode: ViewMode;
    onSelectGame: (game: Game) => void;
}

const GameList: React.FC<GameListProps> = ({ games, isLoading, viewMode, onSelectGame }) => {
    const listClasses = viewMode === ViewMode.GRID
        ? 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6'
        : 'flex flex-col gap-4';

    if (isLoading) {
        return (
            <div className={listClasses}>
                {[...Array(10)].map((_, index) => (
                    <SkeletonCard key={index} viewMode={viewMode} />
                ))}
            </div>
        );
    }
    
    if (games.length === 0) {
        return (
            <div className="text-center py-16">
                <p className="text-2xl font-bold text-gray-700 dark:text-gray-300">
                    
                    No Games Found
                </p>
                <p className="text-gray-500 dark:text-gray-400 mt-2">
                    Try adjusting your search or category filters.
                </p>
            </div>
        )
    }

    return (
        <div className={`${listClasses} animate-fade-in`}>
            {games.map(game => (
                <GameCard key={game.id} game={game} viewMode={viewMode} onSelectGame={onSelectGame} />
            ))}
        </div>
    );
};

export default GameList;
