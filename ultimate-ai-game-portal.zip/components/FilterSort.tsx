
import React from 'react';
import { SortOption, ViewMode, GameCategory } from '../types';
import { GridIcon, ListIcon } from './Icons';

interface FilterSortProps {
    sortOption: SortOption;
    setSortOption: (option: SortOption) => void;
    viewMode: ViewMode;
    setViewMode: (mode: ViewMode) => void;
    gamesCount: number;
    category: GameCategory;
}

const FilterSort: React.FC<FilterSortProps> = ({ sortOption, setSortOption, viewMode, setViewMode, gamesCount, category }) => {
    return (
        <section className="flex flex-col sm:flex-row justify-between items-center mb-6 p-4 bg-white dark:bg-secondary-light rounded-xl shadow-sm">
            <div className="mb-4 sm:mb-0">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">{category} Games</h2>
                <span className="text-sm text-gray-500 dark:text-text-secondary">{gamesCount} items</span>
            </div>
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <label htmlFor="sortSelect" className="text-sm font-medium text-gray-600 dark:text-gray-300">Sort by:</label>
                    <select
                        id="sortSelect"
                        value={sortOption}
                        onChange={(e) => setSortOption(e.target.value as SortOption)}
                        className="bg-gray-100 dark:bg-secondary border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-primary focus:border-primary block w-full p-2"
                    >
                        <option value={SortOption.POPULAR}>Popularity</option>
                        <option value={SortOption.NEWEST}>Newest</option>
                        <option value={SortOption.RATING}>Rating</option>
                        <option value={SortOption.ALPHABETICAL}>A-Z</option>
                    </select>
                </div>
                <div className="flex items-center bg-gray-100 dark:bg-secondary rounded-lg p-1">
                    <button onClick={() => setViewMode(ViewMode.GRID)} className={`p-2 rounded-md transition-colors ${viewMode === ViewMode.GRID ? 'bg-primary text-white' : 'text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`} aria-label="Grid view">
                        <GridIcon />
                    </button>
                    <button onClick={() => setViewMode(ViewMode.LIST)} className={`p-2 rounded-md transition-colors ${viewMode === ViewMode.LIST ? 'bg-primary text-white' : 'text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`} aria-label="List view">
                        <ListIcon />
                    </button>
                </div>
            </div>
        </section>
    );
};

export default FilterSort;
