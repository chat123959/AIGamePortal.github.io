
import React, { useState, useCallback } from 'react';
import ReactDOM from 'react-dom';
import { Game } from '../types';
import { getAIGameSuggestion, AISuggestion } from '../services/geminiService';
import { CloseIcon, SparklesIcon } from './Icons';

interface GeminiGameSuggesterProps {
    isOpen: boolean;
    onClose: () => void;
    games: Game[];
    onPlayGame: (gameTitle: string) => void;
}

const GeminiGameSuggester: React.FC<GeminiGameSuggesterProps> = ({ isOpen, onClose, games, onPlayGame }) => {
    const [preference, setPreference] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [suggestion, setSuggestion] = useState<AISuggestion | null>(null);

    const handleGetSuggestion = useCallback(async () => {
        if (!preference.trim() || isLoading) return;

        setIsLoading(true);
        setSuggestion(null);
        const result = await getAIGameSuggestion(preference, games);
        setSuggestion(result);
        setIsLoading(false);
    }, [preference, games, isLoading]);
    
    const handlePlayClick = () => {
        if (suggestion && suggestion.gameTitle) {
            onPlayGame(suggestion.gameTitle);
        }
    };

    if (!isOpen) return null;

    const modalContent = (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 animate-fade-in" aria-modal="true" role="dialog">
            <div className="fixed inset-0" onClick={onClose} aria-hidden="true"></div>
            <div className="relative bg-secondary-light rounded-2xl shadow-2xl w-full max-w-lg mx-4 p-8 text-white flex flex-col gap-6 animate-slide-up">
                <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors" aria-label="Close suggester">
                    <CloseIcon />
                </button>
                <div className="text-center">
                    <div className="mx-auto bg-primary w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <SparklesIcon className="w-8 h-8 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold">AI Game Suggester</h2>
                    <p className="text-text-secondary mt-1">Tell me what you're in the mood for!</p>
                </div>

                <div>
                    <textarea
                        className="w-full p-3 rounded-lg bg-secondary border-2 border-gray-600 focus:border-primary focus:ring-primary transition-colors text-white placeholder-gray-500"
                        rows={3}
                        placeholder="e.g., 'a fast-paced racing game' or 'a relaxing puzzle game'"
                        value={preference}
                        onChange={(e) => setPreference(e.target.value)}
                        disabled={isLoading}
                    />
                    <button
                        onClick={handleGetSuggestion}
                        className="mt-4 w-full bg-primary hover:bg-primary-hover text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={isLoading || !preference.trim()}
                    >
                        {isLoading ? (
                            <>
                                <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                                <span>Thinking...</span>
                            </>
                        ) : "Get Suggestion"}
                    </button>
                </div>

                {suggestion && (
                    <div className="mt-4 p-4 bg-secondary rounded-lg border border-gray-600 animate-fade-in">
                        <p className="text-center text-lg">{suggestion.recommendation}</p>
                        {suggestion.gameTitle && (
                            <button 
                                onClick={handlePlayClick}
                                className="mt-4 w-full bg-accent hover:bg-pink-600 text-white font-bold py-2 px-4 rounded-full transition-colors"
                            >
                                Play '{suggestion.gameTitle}' Now!
                            </button>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
    
    const modalRoot = document.getElementById('modal-root');
    return modalRoot ? ReactDOM.createPortal(modalContent, modalRoot) : null;
};

export default GeminiGameSuggester;
