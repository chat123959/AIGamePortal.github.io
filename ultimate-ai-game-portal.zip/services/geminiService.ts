
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Game } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Gemini API features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "DISABLED" });

export interface AISuggestion {
    recommendation: string;
    gameTitle: string | null;
}

export const getAIGameSuggestion = async (
    preference: string,
    games: Game[]
): Promise<AISuggestion> => {

    if (!process.env.API_KEY) {
        return {
            recommendation: "The AI Game Suggester is currently unavailable. Please ask the site administrator to configure the Gemini API Key.",
            gameTitle: null,
        };
    }
    
    const gameTitles = games.map(g => g.title).join(', ');

    const prompt = `You are a friendly and helpful game recommender for a website called 'Ultimate AI Game Portal'.
A user is looking for a game suggestion. Their preference is: "${preference}".

Here is a list of available games on the portal: ${gameTitles}.

Analyze the user's preference and recommend ONE game from the list that best fits their request.

Your response MUST be in JSON format, structured exactly like this: 
{
  "recommendation": "A short, friendly sentence explaining why you recommend the game. For example: 'Based on your love for speed, I think you'll have a blast with Galaxy Racer!'",
  "gameTitle": "The exact title of the game you are recommending from the provided list."
}

If no game from the list is a good match for the preference, respond with a creative suggestion for a game they might like anyway, but set "gameTitle" to null.
For example:
{
  "recommendation": "While we don't have an exact match, a game about exploring calm underwater worlds might be perfect for you!",
  "gameTitle": null
}`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.7,
            }
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }

        try {
            const parsedData: AISuggestion = JSON.parse(jsonStr);
            return parsedData;
        } catch (e) {
            console.error("Failed to parse JSON response from Gemini:", e);
            return { recommendation: "The AI had a little trouble thinking. Please try again!", gameTitle: null };
        }

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        return { recommendation: "Sorry, I couldn't connect to the AI brain. Please check the console for errors.", gameTitle: null };
    }
};
